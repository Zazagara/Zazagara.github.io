import { SiteHeader } from "@/components/site-header"
import { Hero } from "@/components/hero"
import { WorkGallery } from "@/components/work-gallery"
import { DiscordCta } from "@/components/discord-cta"

export default function Page() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <Hero />
      <WorkGallery />
      <DiscordCta />
    </main>
  )
}
