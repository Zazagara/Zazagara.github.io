import { ArrowUpRight } from "lucide-react"
import { DISCORD_URL } from "@/lib/site"

export function DiscordCta() {
  return (
    <footer id="discord" className="scroll-mt-24">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <div className="flex flex-col items-center gap-8 rounded-2xl border border-border bg-card px-6 py-16 text-center md:py-20">
          <p className="flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <span className="inline-block h-px w-10 bg-primary" />
            Contact
            <span className="inline-block h-px w-10 bg-primary" />
          </p>
          <h2 className="max-w-2xl text-balance font-heading text-5xl leading-[0.95] tracking-wide md:text-7xl">
            On discute de ton projet ?
          </h2>
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 text-base font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Mon Discord
            <ArrowUpRight className="h-5 w-5" />
          </a>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 md:flex-row">
          <span className="font-heading text-2xl tracking-wide">ZAZAGARA</span>
          <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} Zazagara</p>
        </div>
      </div>
    </footer>
  )
}
