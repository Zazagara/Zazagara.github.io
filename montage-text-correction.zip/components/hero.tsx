import { DISCORD_URL } from "@/lib/site"

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-5 pb-16 pt-32 md:px-8 md:pb-24 md:pt-44">
        <p className="mb-6 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
          <span className="inline-block h-px w-10 bg-primary" />
          Monteur vidéo — YouTube &amp; réseaux sociaux
        </p>

        <h1 className="max-w-5xl font-heading text-[clamp(3rem,11vw,9rem)] leading-[0.9] tracking-tight text-balance">
          Des montages qui
          <span className="text-primary"> captent</span>{" "}
          et retiennent l&apos;attention.
        </h1>

        <div className="mt-8 flex max-w-2xl flex-col gap-6 text-pretty text-lg leading-relaxed text-muted-foreground md:text-xl">
          <p>
            Moi c&apos;est Zazagara, monteur vidéo spécialisé YouTube, Shorts, Reels et TikTok. Je transforme tes rushes
            en contenus dynamiques pensés pour faire grimper la rétention et les vues.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap items-center gap-4">
          <a
            href="#work"
            className="rounded-full bg-primary px-7 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Voir mes montages
          </a>
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-full border border-border px-7 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            Mon Discord
          </a>
        </div>
      </div>
    </section>
  )
}
