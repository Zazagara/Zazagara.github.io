"use client"

import { useRef, useState } from "react"
import { ChevronLeft, ChevronRight, Play } from "lucide-react"

type Project = {
  title: string
  tag: string
  // Colle simplement le lien de ta vidéo : YouTube, Short, youtu.be…
  url: string
}

type CategoryKey = "long" | "short"

// =============================================================
//  AJOUTE TES VIDÉOS ICI
//  Copie une ligne, change le titre, le tag et colle ton lien.
//  La miniature et le lecteur se génèrent automatiquement.
// =============================================================

const longVideos: Project[] = [
  { title: "Le PREMIER Qui Traverse La MAP Sans Enfreindre De LOIS GAGNE Sur GTA 5", tag: "Gaming", url: "https://www.youtube.com/watch?v=MElzAZ8qmqM" },
  { title: "Ne CONTROLLEZ JAMAIS ces BOTS !!", tag: "Gaming", url: "https://www.youtube.com/watch?v=_SFEtG5lxrg" },
]

const shortVideos: Project[] = [
  { title: "L'arnaque impunie d'Atari", tag: "Storytelling", url: "https://www.youtube.com/watch?v=VeksBcef6AI" },
  { title: "Burger décomposé", tag: "Vlog", url: "https://www.youtube.com/watch?v=2VdEocPFGBg" },
]

// Extrait l'identifiant YouTube depuis n'importe quel format de lien
function getYouTubeId(url: string): string | null {
  const match = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/,
  )
  return match ? match[1] : null
}

function ProjectCard({ project, vertical }: { project: Project; vertical: boolean }) {
  const [playing, setPlaying] = useState(false)
  const videoId = getYouTubeId(project.url)
  const thumbnail = videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : null

  return (
    <div
      className={`group relative shrink-0 snap-start overflow-hidden rounded-xl border border-border bg-card ${vertical ? "w-[230px]" : "w-[300px] md:w-[460px]"
        }`}
    >
      <div className={`relative overflow-hidden bg-secondary ${vertical ? "aspect-[9/16]" : "aspect-video"}`}>
        {playing && videoId ? (
          <iframe
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`}
            title={project.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="absolute inset-0 h-full w-full"
          />
        ) : (
          <button
            type="button"
            onClick={() => setPlaying(true)}
            className="absolute inset-0 h-full w-full"
            aria-label={`Lire ${project.title}`}
          >
            {thumbnail ? (
              <img
                src={thumbnail || "/placeholder.svg"}
                alt={`Miniature de ${project.title}`}
                className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
              />
            ) : (
              <span className="flex h-full w-full items-center justify-center text-sm text-muted-foreground">
                Lien de vidéo invalide
              </span>
            )}
            <span className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent" />
            <span className="absolute left-3 top-3 rounded-full border border-border bg-background/70 px-3 py-1 text-[11px] uppercase tracking-[0.15em] text-foreground backdrop-blur-sm">
              {project.tag}
            </span>
            <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-border bg-background/60 text-foreground transition-all duration-300 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground">
              <Play className="h-5 w-5 translate-x-0.5 fill-current" />
            </span>
          </button>
        )}
      </div>
      <div className="flex items-center justify-between gap-4 p-4">
        <h3 className="font-heading text-2xl leading-none tracking-wide">{project.title}</h3>
      </div>
    </div>
  )
}

export function WorkGallery() {
  const [category, setCategory] = useState<CategoryKey>("long")
  const trackRef = useRef<HTMLDivElement>(null)

  const projects = category === "long" ? longVideos : shortVideos
  const vertical = category === "short"

  function scroll(direction: "left" | "right") {
    const track = trackRef.current
    if (!track) return
    const amount = track.clientWidth * 0.8
    track.scrollBy({ left: direction === "left" ? -amount : amount, behavior: "smooth" })
  }

  return (
    <section id="work" className="mx-auto max-w-7xl scroll-mt-24 px-5 py-20 md:px-8 md:py-28">
      <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="mb-3 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <span className="inline-block h-px w-10 bg-primary" />
            Travaux sélectionnés
          </p>
          <h2 className="font-heading text-5xl tracking-wide md:text-6xl">Mes montages</h2>
        </div>

        {/* Sélecteur de catégorie */}
        <div className="inline-flex rounded-full border border-border bg-card p-1">
          <button
            type="button"
            onClick={() => setCategory("long")}
            className={`rounded-full px-5 py-2 text-sm font-medium transition-colors ${category === "long"
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
              }`}
          >
            Vidéos longues
          </button>
          <button
            type="button"
            onClick={() => setCategory("short")}
            className={`rounded-full px-5 py-2 text-sm font-medium transition-colors ${category === "short"
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
              }`}
          >
            Vidéos courtes
          </button>
        </div>
      </div>

      <div className="relative">
        {/* Description + flèches de navigation */}
        <div className="mb-5 flex items-center justify-between gap-4">
          <p className="text-pretty text-muted-foreground">
            {category === "long"
              ? "Vidéos YouTube, vlogs, gaming et podcasts — un montage rythmé qui garde l'attention."
              : "Shorts, Reels et TikToks au format vertical, taillés pour les réseaux sociaux."}
          </p>
          <div className="flex shrink-0 gap-2">
            <button
              type="button"
              onClick={() => scroll("left")}
              aria-label="Précédent"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scroll("right")}
              aria-label="Suivant"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Piste du slider */}
        <div
          ref={trackRef}
          className="flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        >
          {projects.map((project, i) => (
            <ProjectCard key={`${category}-${i}`} project={project} vertical={vertical} />
          ))}
        </div>
      </div>
    </section>
  )
}
