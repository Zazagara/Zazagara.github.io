// Remplace cette valeur par ton vrai lien d'invitation Discord
export const DISCORD_URL = "https://discord.com/users/608295488227377174"
